<?php
define('ROOT_PART', Root_part());
define('APIKEY', 'AIzaSyDUm1v6NWtE_7vjj5rwzLGm2E5TrBBQ5oM');
define('GJ_CODE', 'TW');
define('SITE_NAME', 'youtube');
define('TITLENAME', 'youtube');
define('EN2DEKEY', 'odhagfoadjsfkljadosf5');
define('EMAIL', '550127381@qq.com');
?>